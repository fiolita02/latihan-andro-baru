package com.smartdev.trainingkotlin

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.test.R
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_CalLength.setOnClickListener {
            if(et_volume.text.isNotEmpty() && et_lebar.text.isNotEmpty() && et_tinggi.text.isNotEmpty()){
                var lebar = Integer.valueOf(et_lebar.text.toString())
                var tinggi = Integer.valueOf(et_tinggi.text.toString())
                var volume = Integer.valueOf(et_volume.text.toString())
                var panjang = volume / tinggi / lebar

                (et_panjang as TextView).text = panjang.toString()
            }
            else{
                Toast.makeText(this, "ada kolom yang kosong", Toast.LENGTH_SHORT).show()
            }

        }

        btn_CalHeight.setOnClickListener{
            if (et_volume.text.isNotEmpty() && et_lebar.text.isNotEmpty() && et_panjang.text.isNotEmpty() ){
                var panjang = Integer.valueOf(et_panjang.text.toString())
                var lebar = Integer.valueOf(et_lebar.text.toString())
                var volume = Integer.valueOf(et_volume.text.toString())
                var tinggi = volume / panjang / lebar

                (et_tinggi as TextView).text = tinggi.toString()
            }else{
                Toast.makeText(this, "ada kolom yang kosong", Toast.LENGTH_SHORT).show()
            }

        }
        btn_CalWidth.setOnClickListener{
            if (et_volume.text.isNotEmpty() && et_panjang.text.isNotEmpty() && et_tinggi.text.isNotEmpty()){
                var panjang = Integer.valueOf(et_panjang.text.toString())
                var tinggi = Integer.valueOf(et_tinggi.text.toString())
                var volume = Integer.valueOf(et_volume.text.toString())
                val lebar = volume / panjang / tinggi

                (et_lebar as TextView).text = lebar.toString()
            }else{
                Toast.makeText(this, "ada kolom yang kosong", Toast.LENGTH_SHORT).show()
            }

        }

        btn_CalVolume.setOnClickListener {
            if (et_panjang.text.isNotEmpty() && et_tinggi.text.isNotEmpty() && et_lebar.text.isNotEmpty()){
                var panjang = Integer.valueOf(et_panjang.text.toString())
                var lebar = Integer.valueOf(et_lebar.text.toString())
                var tinggi = Integer.valueOf(et_tinggi.text.toString())
                var volume = panjang * lebar * tinggi

                (et_volume as TextView).text = volume.toString()
            }else{
                Toast.makeText(this, "ada kolom yang kosong",Toast.LENGTH_SHORT).show()
            }

        }

    }
}